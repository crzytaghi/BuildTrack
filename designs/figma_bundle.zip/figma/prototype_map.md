
# Prototype Link Map (Figma)

Web
- Dashboard -> Projects (click KPI or Projects nav)
- Projects List -> Project Detail (click project row)
- Project Detail -> Tasks (tab)
- Project Detail -> Budget (tab)
- Project Detail -> Expenses (tab)
- Project Detail -> Documents (tab)
- Project Detail -> Reports (tab)
- Expenses List -> Add Expense (Add Expense button)
- Reports -> Export (Export PDF button)
- Settings -> Invite User (Invite User button)

Mobile
- Home -> Project Detail (project card)
- Project Detail -> Tasks (tasks card)
- Project Detail -> Budget (budget summary)
- Home -> Expenses (recent expenses card)
- Expenses -> Add Expense (floating action button)
- Home -> Documents (top nav or shortcut)
- Home -> Reports (top nav or shortcut)
